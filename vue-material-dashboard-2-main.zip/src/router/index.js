import { createRouter, createWebHistory } from "vue-router";
import Dashboard from "../views/Dashboard.vue";
import Tables from "../views/Tables.vue";
import Billing from "../views/Billing.vue";
import Notifications from "../views/Notifications.vue";
import Profile from "../views/Profile.vue";
import SignIn from "../views/SignIn.vue";
import SignUp from "../views/SignUp.vue";
import Custom from "../views/Custom.vue";
import Graphs from "../views/Graphs.vue";
import GoJsDiagram from "../views/GoJsDiagram.vue";
import PrimeTable from "../views/PrimeTable.vue";

const routes = [
  {
    path: "/",
    name: "/",
    redirect: "/dashboard",
  },
  {
    path: "/dashboard",
    name: "Dashboard",
    component: Dashboard,
  },
  {
    path: "/tables",
    name: "Tables",
    component: Tables,
  },
  {
    path: "/billing",
    name: "Billing",
    component: Billing,
  },
  {
    path: "/notifications",
    name: "Notifications",
    component: Notifications,
  },
  {
    path: "/profile",
    name: "Profile",
    component: Profile,
  },
  {
    path: "/sign-in",
    name: "SignIn",
    component: SignIn,
  },
  {
    path: "/sign-up",
    name: "SignUp",
    component: SignUp,
  },
  {
    path: "/custom",
    name: "Custom",
    component: Custom,
  },
  {
    path: "/graphs",
    name: "Graphs",
    component: Graphs,
  },
  {
    path: "/gojs-diagram",
    name: "GoJsDiagram",
    component: GoJsDiagram,
  },
  {
    path: "/primetable",
    name: "PrimeTable",
    component: PrimeTable
  },
];

const router = createRouter({
  history: createWebHistory(process.env.BASE_URL),
  routes,
  linkActiveClass: "active",
});

export default router;
