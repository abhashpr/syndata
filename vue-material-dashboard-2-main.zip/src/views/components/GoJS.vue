<template>
    <div id="myDiagramDiv"></div>
</template>
  
<script>
  import * as go from 'gojs';
  import { VueGoDiagram } from 'gojs-vue'; // If you're using gojs-vue
  
  export default {
    name: 'GoJsDiagram',
    components: { VueGoDiagram }, // If you're using gojs-vue
    mounted() {
      const $ = go.GraphObject.make;
      const diagram = new go.Diagram("myDiagramDiv");
  
      // Define your diagram's node template, model, and other configurations here
      diagram.nodeTemplate = $(go.Node, "Auto", /* Your node template */);
      diagram.model = new go.GraphLinksModel(/* Your model data */);
    },
  };
</script>