<template>
    <div class="row" style="margin: 50px 0 100px 100px">
        <div class="col-sm-8">
            <div class="table-responsive">
                <DataTable 
                    :data="products" 
                    :columns="columns" 
                    class="table table-lg display"
                    :options="{responsive:true, autowidth:false, dom:'Bfrtip'}"
                    style="color: #000"
                    >
                    <thead>
                    <tr>
                        <th>#</th>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Status</th>
                    </tr>
                    </thead>
                    <tbody></tbody>
                </DataTable>
            </div>
        </div>
    </div>
  </template>
  
<script>
// eslint-disable-next-line no-unused-vars
import axios from 'axios';
import DataTable from 'datatables.net-vue3';
import DataTableLib from 'datatables.net-bs5';
import Buttons from 'datatables.net-buttons-bs5';
import ButtonsHtml5 from 'datatables.net-buttons/js/buttons.html5';
import print from 'datatables.net-buttons/js/buttons.print';
import pdfmake from 'pdfmake';
import pdfFonts from 'pdfmake/build/vfs_fonts';
pdfmake.vfs = pdfFonts.pdfMake.vfs;
import 'datatables.net-responsive-bs5';
import JsZip from 'jszip';
window.JsZip = JsZip;

DataTable.use(DataTableLib);
DataTable.use(pdfmake);
DataTable.use(ButtonsHtml5);

export default{
    components: {DataTable},
    data() {
        return {
            products: null,
            columns: [
                {
                    data: null, render: function(data, type, row, meta) 
                        {return `${meta.row+1}`}
                },
                {data:'id'},
                {data:'name'},
                {data:'status'}
            ]
        }
    },
    mounted() {
        this.getProducts();
    },
    methods: {
        getProducts() {
            axios.get('https://finalspaceapi.com/api/v0/character').then(
                response => {
                    this.products = response.data
                }
            );
        }
    }
};
</script>
<style>
@import 'datatables.net-bs5';
</style>
  