<template>
    <div id="chart-wrapper">
        <v-chart class="chart" :option="pieOptions" autoresize />
        <v-chart class="chart" :option="barOptions" autoresize />
        <v-chart class="chart" :option="lineOptions" autoresize />
    </div>
</template>
  
<script setup>
    import { use } from 'echarts/core';
    import { CanvasRenderer } from 'echarts/renderers';
    import { PieChart, BarChart, LineChart } from 'echarts/charts';
    import { TitleComponent, GridComponent, TooltipComponent, LegendComponent } from 'echarts/components';
    import VChart, { THEME_KEY } from 'vue-echarts';
    import { ref, provide } from 'vue';
  
    use([
        CanvasRenderer,
        GridComponent,
        BarChart,
        LineChart,
        PieChart,
        TitleComponent,
        TooltipComponent,
        LegendComponent,
    ]);
  
    provide(THEME_KEY, 'light');    
    const pieOptions = ref({
        title: {
            text: 'Traffic Sources',
            left: 'center',
        },
        tooltip: {
            trigger: 'item',
            formatter: '{a} <br/>{b} : {c} ({d}%)',
        },
        legend: {
            orient: 'vertical',
            left: 'left',
            data: ['Direct', 'Email', 'Ad Networks', 'Video Ads', 'Search Engines'],
        },
        series: [
                    {
                        name: 'Traffic Sources',
                        type: 'pie',
                        radius: '55%',
                        center: ['50%', '60%'],
                        data: [
                            { value: 335, name: 'Direct' },
                            { value: 310, name: 'Email' },
                            { value: 234, name: 'Ad Networks' },
                            { value: 135, name: 'Video Ads' },
                            { value: 1548, name: 'Search Engines' },
                        ],
                        emphasis: {
                            itemStyle: {
                                shadowBlur: 10,
                                shadowOffsetX: 0,
                                shadowColor: 'rgba(0, 0, 0, 0.5)',
                            },
                        },
                    },
                ],
    });

    const barOptions = ref(
        {
                // textStyle: {
                //     fontFamily: 'Inter, "Hevletica Neue"'
                // },
                title: {
                    text: 'Weekly Sales',
                    left: 'center'
                },
                tooltip: {
                    trigger: 'item',
                    formatter: '{a} <br/> {b}: {c}'
                },
                xAxis: {
                    type: 'category',
                    data: ['MON', 'TUE', 'WED', 'THUR', 'FRI', 'SAT', 'SUN']
                },
                yAxis: {
                    type: 'value'
                },
                legend: {
                    data: ['Sales']
                },
                series: [
                    {
                        data: ['30000', '40000', '50000', '10000', '5000', '9000', '7800'],
                        type: 'bar',
                        showBackground: true,
                        backgroundStyle: {
                            color: 'rgba(255, 255, 255, 0.1)'
                        }
                    }
                ]

            }
        );

        const lineOptions = ref(
            {
                // textStyle: {
                //     fontFamily: 'Inter, "Hevletica Neue"'
                // },
                title: {
                    text: 'Weekly Sales',
                    left: 'center'
                },
                tooltip: {
                    trigger: 'item',
                    formatter: '{a} <br/> {b}: {c}'
                },
                xAxis: {
                    type: 'category',
                    data: ['MON', 'TUE', 'WED', 'THUR', 'FRI', 'SAT', 'SUN']
                },
                yAxis: {
                    type: 'value'
                },
                legend: {
                    data: ['Sales']
                },
                series: [
                    {
                        data: [150, 230, 120, 450, 137, 147, 260],
                        type: 'line',
                    }
                ]

            }
        );

  
</script>
  
<style scoped>
  .chart {
    height: 50vh;
    margin: 10px 0 50px 100px;
    width: 40%;
    float: left;
  }

  #chart-wrapper {
    margin-top: 70px;
  }

</style>
  