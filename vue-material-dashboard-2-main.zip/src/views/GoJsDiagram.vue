<template>
  <div id="diagramDiv" :style="{ width: '100%', height: '400px' }"></div>
</template>

<script>
import go from 'gojs';
// import VueDiagram from 'gojs-vue';

export default {
  name: 'GojsDiagram',
  components: {
    // VueDiagram
  },
  mounted() {
    const $ = go.GraphObject.make;

    // this.diagram = $(go.Diagram, this.$refs.diagramDiv, {
    //   // Diagram configuration options here
    //   "undoManager.isEnabled": true
    // });
    this.myDiagram = new go.Diagram('diagramDiv', {
    'undoManager.isEnabled': true // enable undo & redo
  });
    // Define your nodes and links here
  //   this.diagram.nodeTemplate = $(go.Node, "Auto",
  //     // Node configuration options here
  //     new go.Node("Auto").add(  
  //     // the Shape will go around the TextBlock
  //     new go.Shape("RoundedRectangle")
  //     // Shape.fill is bound to Node.data.color
  //     .bind("fill", "color"),
  //     new go.TextBlock({ margin: 3 })  // some room around the text
  //     // TextBlock.text is bound to Node.data.key
  //     .bind("text", "key")
  //   )
  // );

    // Load your data into the diagram
    // this.diagram.model = new go.GraphLinksModel(
    //   // Your data here
    //   [
    //     { key: "Alpha", color: "lightblue" },
    //     { key: "Beta", color: "orange" },
    //     { key: "Gamma", color: "lightgreen" },
    //     { key: "Delta", color: "pink" }
    //   ],
    //   [
    //     { from: "Alpha", to: "Beta" },
    //     { from: "Alpha", to: "Gamma" },
    //     { from: "Beta", to: "Beta" },
    //     { from: "Gamma", to: "Delta" },
    //     { from: "Delta", to: "Alpha" }
    //   ]
    // );

  // this.diagram.add(
  // // all Parts are Panels
  // new go.Part(go.Panel.Position,  // or "Position"
  //     { background: "lightgray" })
  //   .add(
  //     new go.TextBlock("default, at (0,0)", { background: "lightgreen" }),
  //     new go.TextBlock("(100, 0)", { position: new go.Point(100, 0), background: "lightgreen" }),
  //     new go.TextBlock("(0, 100)", { position: new go.Point(0, 100), background: "lightgreen" }),
  //     new go.TextBlock("(55, 28)", { position: new go.Point(55, 28), background: "lightgreen" }),
  //     new go.TextBlock("(33, 70)", { position: new go.Point(33, 70), background: "lightgreen" }),
  //     new go.TextBlock("(100, 100)", { position: new go.Point(100, 100), background: "lightgreen" })
  //   ));

//   this.diagram.nodeTemplate =
//   new go.Node("Auto")
//     .add(
//       new go.Shape("Rectangle")
//         .bind("fill", "color"),
//       new go.TextBlock({ margin: 5 })
//         .bind("text")
//     );

// this.diagram.model.nodeDataArray = [
//   { text: "Alpha", color: "lightblue" }
// ];


// try getting rid of this part--the default node template will just make the node appear as the text
this.myDiagram.nodeTemplate = new go.Node('Auto')
    .add(
      // two elements: the Shape will go around the TextBlock
      new go.Shape('RoundedRectangle', { strokeWidth: 0, fill: 'white' }) // no border; default fill is white
        .bind('fill', 'color'), // Shape.fill is bound to Node.data.color
      new go.TextBlock({ margin: 8, font: 'bold 14px sans-serif', stroke: '#333' }).bind('text') // some room around the text, bold font // TextBlock.text is bound to Node.data.text
    );

  // but use the default Link template, by not setting Diagram.linkTemplate

  // create the model data that will be represented by Nodes and Links
  this.myDiagram.model = new go.GraphLinksModel(
    [
      { key: 1, text: 'Alpha', color: 'lightblue' },
      { key: 2, text: 'Beta', color: 'orange' },
      { key: 3, text: 'Gamma', color: 'lightgreen' },
      { key: 4, text: 'Delta', color: 'pink' }
    ],
    [
      { from: 1, to: 2 },
      { from: 1, to: 3 },
      { from: 2, to: 2 },
      { from: 3, to: 4 },
      { from: 4, to: 1 }
    ]
  );
  }
}
</script>